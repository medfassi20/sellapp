package esisa.ac.ma.project1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
