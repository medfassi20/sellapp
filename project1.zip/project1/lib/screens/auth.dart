import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import 'package:flutter/material.dart';
import 'package:project1/screens/home.dart';

class Authentication extends StatefulWidget {
  const Authentication({super.key});

  @override
  State<Authentication> createState() => _AuthenticationState();
}

class _AuthenticationState extends State<Authentication> {
  final _emailController = TextEditingController();

  final _passWordController = TextEditingController();

  var isValid = false;
  @override
  void dispose() {
    super.dispose();
    _emailController.dispose();
    _passWordController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //appBar = named parameter
      appBar: AppBar(title: const Text('Authentication')),
      body: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height / 6,
          ),
          const Icon(Icons.login),
          const Padding(padding: EdgeInsets.all(10)),
          TextField(
            controller: _emailController,
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(),
                hintText: 'Email',
                label: Text('Email')),
          ),
          const Padding(padding: EdgeInsets.all(10)),
          TextField(
            obscureText: true,
            controller: _passWordController,
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.lock),
                border: OutlineInputBorder(),
                hintText: 'Password',
                label: Text('Password')),
          ),
          const Padding(padding: EdgeInsets.all(10)),
          ElevatedButton(
            onPressed: () => {
              /*
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(_emailController.text)))*/
              if (_emailController.text.isEmpty ||
                  _passWordController.text.isEmpty)
                setState(() {
                  isValid = true;
                })
              else
                setState(() {
                  isValid = false;
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => const Home()));
                })
            },
            child: const Text('Login'),
          ),
          const Padding(padding: EdgeInsets.all(10)),
          Text(isValid == false ? '' : 'email or password is Empty',
              style: const TextStyle(
                color: Colors.red,
              ))
        ],
      ),
    );
  }
}
