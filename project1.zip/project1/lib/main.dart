import 'package:flutter/material.dart';
import 'package:project1/screens/auth.dart';

void main() {
  runApp(const MainApp());
}

//statelessWidget
class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    //materialApp = MainActivity
    //tout les wiedget ont declaré comme un arbre
    return MaterialApp(
      //scaffold is a container
      home: Authentication(),
      debugShowCheckedModeBanner: false,
    );
  }
}
